public class AVLSearchTree extends BinarySearchTree {
	public AVLSearchTree(){
		super();
	}

	public void insert(MyObject toAdd){
		//TODO
	}
	
	public void remove(Comparable toRemove){
		//TODO
	}
	
	

	
}
