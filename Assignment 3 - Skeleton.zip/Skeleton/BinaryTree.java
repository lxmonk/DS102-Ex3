
public class BinaryTree {
	protected BinaryNode root;
	
	/*
	 * create an empty tree
	 */
	public BinaryTree(){
		//TODO
	}

	/*
	 * returns the tree height
	 */
	public int height(){
		//TODO
	}

	/*
	 * returns true iff the tree is empty
	 */
	public boolean isEmpty(){
		//TODO
	}

	/*
	 * print the tree inorder
	 */
	public void printInOrder(){
		//TODO
	}

	/*
	 * print the tree by levels
	 */
	public void printByLevels(){
		//TODO
	}

	
	
	
	
	
	
	
	
	
	//NOT REALLY IMPLEMENTED
	public void remove(Comparable o){
	}

	
	
	
}