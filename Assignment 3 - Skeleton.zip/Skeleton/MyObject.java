
public interface MyObject extends Comparable{


	public Comparable getKeyData();
	public Comparable getMaxData();
	public boolean overlap(Comparable start, Comparable end);
}
